import { DashboardSearchPipe } from './dashboard-search.pipe';

describe('DashboardSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new DashboardSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
